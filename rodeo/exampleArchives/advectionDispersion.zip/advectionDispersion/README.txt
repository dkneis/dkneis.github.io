Demo example for R-package rodeo, 2016-04-21, david.kneis@tu-dresden.de

This example demonstrates the solution of a 1D partial differential
equation problem by means of semi-discretization (method-of-lines).

The model simulates the transport of a conservative tracer along a
river reach assuming steady-uniform flow (i.e. constant velocity).
The quality of the numeric solution is assessed by (visual) comparison
with the analytical solution.

The example uses generated Fortran code. It relies on R's developer
tools being installed (Fortran compiler and respective utilities).
