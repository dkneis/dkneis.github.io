cUp <- function (time) { 0 }
cDn <- function (time) { 0 }

