rm(list=ls())

# Data import
###################################################
trees <- read.table(file="../data/trees.txt",
  sep="\t", header=TRUE)
print(trees[1:3, ], row.names=FALSE)         # rows 1-3


# Histograms and means
###################################################
par(mfrow=c(1,2))                           # 2 plots/row
with(trees, {
  hist(height[exposure=="North"], main="")
  hist(height[exposure=="South"], main="")
  tapply(height, exposure, mean)            # Group means
})


# Visual check for normality
###################################################
par(mfrow=c(1,2))                            # 2 plots/row
with(trees, {
  for (group in unique(exposure)) {
    qqnorm(height[exposure == group], main="")
    qqline(height[exposure == group])
    legend("topleft", bty="n", legend=group)
  }
})


# t-test, allowing for unequal variance in groups
###################################################
t.test(height ~ exposure, data=trees)

