rm(list=ls())

# Data import
###################################################
dat <- read.table(file="../data/heatpump.txt",
  sep="\t", header=TRUE)                      # TAB-delim.
print(dat[1:3, ], row.names=FALSE)            # top rows


# Basic inspection
###################################################
nrow(dat)                    # number of records
colSums(dat[,2:3])           # sum over rows
range(dat$power)             # data range of a vector
summary(dat$heat)            # summary for numeric data


# Histogram
###################################################
hist(dat$heat, main="")


# Scatter plot
###################################################
plot(x=dat$heat, y=dat$power)


# Simplified access to columns
###################################################
with(dat, {
  plot(x=heat, y=power)
})


# Adding a derived column
###################################################
dat$year <- as.numeric(substr(dat$date,1,4))
print(dat[1:3, ], row.names=FALSE)


# Labels, colors, legend
###################################################
# Function to assign colors to years; vector-valued
f <- function(x) {
  col <- rep("black", length(x))
  col[x == 2015] <- "steelblue"
  col[x == 2016] <- "darkorange"
  col
}

plot(x=dat$heat, y=dat$power, pch=16, col=f(dat$year),
  xlab="Extracted heat (kWh)", ylab="Power (kWh)")
legend("topleft", bty="n", pch=16, col=f(range(dat$year)),
  legend=range(dat$year))

