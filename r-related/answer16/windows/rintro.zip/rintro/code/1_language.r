rm(list=ls())


# Ingredients of a script
###################################################
x <- runif(1)  # assigns a random number to variable 'x'
if (x > 0.5)   # test a condition
  print(x)     # call to 'print' function


# Assignment to scalar variables
###################################################
x <- 3.1415          # numeric
x <- "E. coli"       # character (overwrites old value)
x <- TRUE            # logical
x <- list(id=1,      # creates a list
  name="E. coli",
  rodShaped=TRUE)


# Info about a variable
###################################################
print(x)    # print value
typeof(x)   # returns the type
is.list(x)  # type check (is.numeric, is.character, ...)
str(x)      # structure; useful for large lists


# Vector constructors I
###################################################
x <- seq(from=0, to=2, by=0.25)       # numeric sequence
x <- 1:5                              # integer sequence
x <- rep(0, times=3)                  # replication


# Vector constructors II
###################################################
x <- c("Athens", "Paris", "Rome")     # vector of strings
x <- c(red=255, green=0, blue=128)    # elements named


# Some vector-related functions
###################################################
length(x)                             # number of elements
names(x)                              # element names


# Vector subsetting I: By position
###################################################
x[1]                    # 1st element
x[1:2]                  # using a vector of positions


# Vector subsetting II: By name
###################################################
x["red"]                # single element
x[c("blue","red")]      # using a vector of names


# Vector subsetting III: By mask
###################################################
x[x > 0]                # logical mask
x[which(x > 0)]         # a more explicit alternative


# Matrix constructors I
###################################################
x <- matrix(1:6, nrow=2, ncol=3, byrow=FALSE)


# Matrix constructors II
###################################################
x <- cbind(temp= c(0, 10, 20),           # 1st column
           rate= c(0, 0.2, 0.4))         # 2nd column


# Matrix constructurs III
###################################################
x <- rbind(
  tap=   c(NO3= 0.5, NH4=  0, O2=12),    # 1st row
  river= c(NO3=   5, NH4=  1, O2=10),
  WWTP=  c(NO3=  10, NH4= 10, O2= 3))


# Matrix attributes
###################################################
ncol(x)            # number of columns
nrow(x)
colnames(x)        # column names
rownames(x)


# Matrix subsetting
###################################################
x[1, ]                 # 1st row (vector)
x[, 1]                 # 1st column (vector)
x[1, 1]                # top left element (scalar)
x[1:2, 2:ncol(x)]      # sub-matrix
x[x[,"O2"] > 5, "O2"]  # subset by name / logical mask


# Data frame (constructor)
###################################################
x <- data.frame(
  element= c("C", "Si", "N", "P"),
  group=   c(4, 4, 5, 5),
  mass=    c(12.01, 28.09, 14.01, 30.97)
)


# Data frane, treated as a matrix
###################################################
ncol(x)       # also 'nrow(x)'
colnames(x)   # also 'rownames(x)'
x[ ,3]        # last column, access by index
x[ ,ncol(x)]  #   as above
x[ ,"mass"]   # last column, access by name
x[1, ]        # first row, returns a list!


# Data frame, treated as a list
###################################################
names(x)      # same as 'colnames(x)'
x$element     # extract column


# Basic numeric operators
###################################################
x <- 1:10
x * 2     # each element multiplied with scalar
x * x     # operands of same length: works element-wise


# Matrix multiplication
###################################################
x <- matrix(1:6, ncol=3)
y <- matrix(1:6, ncol=2, byrow=TRUE)
x %*% y


# Comparisons (for basic data types)
###################################################
x <= 5      # comparison for each element
!(x == 5)   # negation, same as 'x != 5'


# Logical AND/OR
###################################################
x <- c(TRUE, FALSE)
y <- c(FALSE, TRUE)
x & y                 # element wise AND
x | y                 # element wise OR


# String manipulation I: Concatenation
###################################################
paste("use", "R", sep="")     # 'sep' specifies the glue
paste("matrix is of size",    # auto-converts numbers
   nrow(x), "x", ncol(x))


# String manipulation II: Substrings
###################################################
substring("function", 1, 3)


# Conditional expressions I
###################################################
x <- runif(1)        # single random number, range [0,1]
if (x > 0.5) {       # logical statement
  print("greater")   # executed if TRUE
}                    # { } define a block of statements


# Conditional expressions II
###################################################
if (x > 0.5) {
  print("greater")
} else if (x < 0.5) {  # optional alternative condition(s)
  print("less")        
} else {               # if all conditions are FALSE
  print("equal")       # very unlikely to be printed ever
}


# Iterating over elements of a vector (for loop)
###################################################
x <- 1:8
for (i in x) {      # i cycles through the elements of x
  print(2 ^ i)
}


# Repeated execution (while loop)
###################################################
x <- 1
while (x > 0.1) {   # (non)-exit condition
  print(x)
  x <- runif(1)
}


# Functions: Definition
###################################################
foo <- function(x) {   # single argument function
  lowest <- min(x)     # processing of arguments
  highest <- max(x)    # + use of local variables
  c(lowest, highest)   # return value
}                      # closes body


# Functions: Call
###################################################
y <- rnorm(n=100, mean=0, sd=1)    # sample from N(0,1)
foo(y)                             # same as range(y)


# Functions: Reference to a global variable (bad style)
###################################################
bad <- function (x) { x * a }  # origin of 'a' not obvious
a <- 2
bad(3)

