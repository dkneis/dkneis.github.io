rm(list=ls())

# display info on R
R.version

# display working directory
getwd()

