rm(list=ls())

# Data import
###################################################
d <- read.table(file="../data/growth.txt",
  sep="\t", header=TRUE)
print(d[1:3, ], row.names=FALSE)


# Plot dynamics
###################################################
par(mfrow=c(1,2))
plot(d$time, d$dens, xlab="Hour", ylab="OD_600", las=2)
plot(d$time, d$dens, log="y", xlab="Hour", ylab="", las=2)


# Methods I: Numerical int. - Install/load solvers 
###################################################
install.packages("deSolve")          # install ODE solvers
library("deSolve")                   # load solvers


# Methods I: Numerical int. - Function returning derivatives
###################################################
model <- function(time, y, p) {      # deSolve compliant
  list(c( dYi = -p["w"] * y["Yi"],   # y: state vector
          dYa = p["w"] * y["Yi"] +   # p: param. vector
                p["g"] * y["Ya"] * 
                (1 - (y["Ya"] + y["Yi"]) / p["K"])
  ))
}


# Methods II: Optimization - Objective function
###################################################
objFunc <- function(p, obs) {
  # get Ya(t) and Yi(t) for current param. (integration)
  sim <- deSolve::ode(y=c(Yi=p[["Yi0"]], Ya=p[["Ya0"]]),
    time=obs$time, func=model,
    parms=c(w=p[["w"]], g=p[["g"]], K=p[["K"]]))
  # compare Ya(t) + Yi(t) to observations
  sum((obs$dens - apply(sim[,2:3], 1, sum))^2)
}


# Estimating the parameters: Initial guess
###################################################
guess <- c(Yi0=0.001, Ya0=0.001, w=0.1, g=0.3, K=0.06)


# Estimating the parameters: Optimization with box-constraints
###################################################
fit <- optim(par=guess, fn=objFunc, gr=NULL, obs=d,
  method="L-BFGS-B",
  lower=c(Yi0=0, Ya0=0, w=0, g=0, K=0.04),
  upper=c(Yi0=Inf, Ya0=Inf, w=Inf, g=Inf, K=0.08),
  control=list(parscale=guess))
if (fit$convergence != 0)
  stop("fitting failed")


# Result: Return value of optimizer 
###################################################
fit$par <- signif(fit$par, 4)
print(fit)


# Result: Plotting the best fit
###################################################
par(mfrow=c(1,1))
with(as.list(fit$par), {
  int <- deSolve::ode(y=c(Yi=Yi0, Ya=Ya0),
    time=d$time, func=model, parms=c(w=w, g=g, K=K))
  plot(d$time, d$dens, xlab="Hour", ylab="OD_600", las=2)
  lines(int[,1], apply(int[,2:3], 1, sum))
  legend("bottomright", bty="n", pch=c(1,NA),
    lty=c(NA,1), legend=c("Observed", "Model"))
})


