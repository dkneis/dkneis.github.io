rm(list=ls())

# Data import / preparation
###################################################
dat <- read.table(file="../data/salt.txt",
  sep="\t", header=TRUE)
dat$cond <- 1 / dat$resist               # get conductance
print(dat[1:3, ], row.names=FALSE)       # show top rows


# Visual check for linearity
###################################################
with(dat, plot(x=salt, y=cond))


# Estimate coefficients
###################################################
fit <- lm(cond ~ salt, data=dat)
summary(fit)


# Plotting regression results
###################################################
plot(dat$salt, dat$cond)                        # scatter
lines(dat$salt, predict(fit, interval="none"))  # add line

fitted <- signif(coef(fit), 3)                  # extract
names(fitted) <- c("intercept", "slope")        #   coeff.
legend("topleft", bty="n", legend=paste(names(fitted),
  fitted, sep=": "))

x <- data.frame(salt=pretty(dat$salt, 100))
confLim <- predict(fit, newdata=x, interval="conf")
predLim <- predict(fit, newdata=x, interval="pred")
for (lim in c("lwr", "upr")) {
  lines(x$salt, confLim[,lim], lty=2)
  lines(x$salt, predLim[,lim], lty=3)
}


# Confidence limits of coefficients: Standard
###################################################
confint(fit)


# Confidence limits of coefficients: Bootstrap
###################################################
library(boot)
f <- function(x, i) {
  coef(lm(x$cond[i] ~ x$salt[i], data=x))}
cf <- boot(dat, f, R=1000)$t                     # 1000 x
t(apply(cf, 2, quantile, probs=c(0.025, 0.975)))


# Inspection of residuals
###################################################
par(mfrow=c(1,2))                      # 2 plots/row
plot(predict(fit), residuals(fit),     # Homoscedasticity?
  xlab="Predicted", ylab="Residuals") 
qqnorm(fit$residuals, main="")         # Normal QQ plot
qqline(fit$residuals, col="red")       # Through quartiles

