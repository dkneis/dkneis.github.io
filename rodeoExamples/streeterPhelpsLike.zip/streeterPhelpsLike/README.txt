Demo example for R-package rodeo, 2016-04-21, david.kneis@tu-dresden.de

The model simulates aerobic 1st-order decay of a substance in a stirred
tank reactor without in- or outflow. The state variables are degradable
organic matter (OM) and dissolved oxygen (DO). This is in contrast to
the classical Streeter-Phelps model which considers biochemical oxygen
demand, BOD, (rather than OM) and the oxygen deficit (rather than DO).

This demo model is reduced to the basics. It assumes that oxygen never
becomes limiting, hence, non-sense is returned if the system goes
anaerobic. The model does not account, e.g., for temperature dependence
of micribioal activity, it does not distinguish between CBOD and NBOD,
there is no interaction between water and sediment, ...

The example can be run using either pure R or generated Fortran code.
In the latter case, R's developer tools must being installed (Fortran
compiler and respective utilities).
